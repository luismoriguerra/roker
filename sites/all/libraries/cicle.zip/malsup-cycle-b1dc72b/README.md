jQuery Cycle Plugin
===================

Cycle is an easy-to-use slideshow plugin that provides many options and effects for creating beautiful slideshows.

Links

* [Home Page](http://jquery.malsup.com/cycle/)
* [Options Reference](http://jquery.malsup.com/cycle/options.html)
* [Effects Browser](http://jquery.malsup.com/cycle/browser.html)
* [Download](http://jquery.malsup.com/cycle/download.html)
 